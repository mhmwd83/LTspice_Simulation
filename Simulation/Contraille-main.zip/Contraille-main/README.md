# Contraille
A control block library for LTspice XVII

Description of this LTspice library can be found in my blog, but currently only in the Japanese language.
